from django.apps import AppConfig


class LoginModuleConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'login_module'
    verbose_name = 'اطلاعات'