from django import forms
from login_module.models import ContactUs

class ContactUsForm(forms.Form):
    full_name = forms.CharField(label='نام و نام خانوادگی',required=False , error_messages={
        'required' : 'لطفا نام خود را وارد کنید'
    } , widget=forms.TextInput(attrs={
        'class' : 'form-control' ,
        'placeholder' : "نام و نام خانوادگی"
    }))
    email = forms.EmailField(label='ایمیل' , widget=forms.EmailInput(attrs={
        'class' : 'form-control' , 
        'placeholder' : 'ایمیل'
    }))
    message = forms.CharField(label='متن پیام ' , widget=forms.Textarea(attrs={
        'class' : 'form-control' ,
        'placeholder' : " پیام شما"
    }))
    
class ContactUsModelForm(forms.ModelForm):
    class Meta:
        model = ContactUs
        fields = ['full_name' , 'email'  , 'message']
        widgets = {
            'full_name': forms.TextInput(attrs={
                'class': 'form-control'
            }),
            
            'email': forms.TextInput(attrs={
                'class': 'form-control'
            }),
            
            'title': forms.TextInput(attrs={
                'class': 'form-control'
            }),
            
            'message': forms.Textarea(attrs={
                'class': 'form-control' ,
                'rows' : 5,
                'id':'message'
            })
        }
        labels = {
            'full_name' : 'نام و نام خانواگی شما',
            'email' : 'ایمیل شما'

        }