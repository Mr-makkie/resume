from django.db import models

# Create your models here.

class InfoModel(models.Model):
    title =models.CharField(max_length=300 , verbose_name='عنوان ')
    name= models.CharField(max_length=200 , verbose_name='اسم شما')
    about = models.TextField(verbose_name='درباره شما')
    ncustom = models.PositiveIntegerField(verbose_name='تعداد مشتریان' , null=True)
    nproject = models.PositiveIntegerField(verbose_name='تعداد پروژه', null=True)
    ncode = models.PositiveIntegerField(verbose_name='تعداد خط کد', null=True)
    image = models.ImageField(verbose_name='عکس شما' , upload_to='images/profiles')
    email = models.EmailField(verbose_name='ایمیل شما' , null=True)
    mobile = models.CharField(max_length=200 , verbose_name='شماره تلفن شما' , null=True)
    addres = models.TextField(verbose_name='ادرس شما' , null=True)
    is_main = models.BooleanField(verbose_name='اطلاعات اصلی / غیراصلی')

    class Meta:
        verbose_name = 'اطلاعات شما'
        verbose_name_plural = 'اطلاعات'
    def __str__(self):
        return self.title
    
class DomailModel(models.Model):
    title = models.CharField(max_length=200 , verbose_name='عنوان حوزه فعالیت شما')
    info= models.CharField(max_length=300 , verbose_name='توضیحات کوتاه حوزه')
    class Meta:
        verbose_name = 'فعالیت شما'
        verbose_name_plural = 'فعالیت های شما'
    def __str__(self):
        return self.title
    
class WorksView(models.Model):
    image = models.ImageField(verbose_name='عکس پروژه شما')
    class Meta:
        verbose_name = 'عکس پروژه'
        verbose_name_plural = 'عکس های پروژه'
    
class PartnerModel(models.Model):
    name = models.CharField(max_length=300 , verbose_name='نام همکار شما')
    info = models.TextField(verbose_name='اطلاعات همکار شما')
    image = models.ImageField(verbose_name='عکس همکار شما')
    class Meta:
        verbose_name = 'همکار شما'
        verbose_name_plural = 'همکاران شما'
    def __str__(self):
        return self.name
class ContactUs(models.Model):
    email = models.EmailField(max_length=200 , verbose_name='ایمیل')
    full_name = models.CharField(max_length=300 , verbose_name='نام')
    message = models.TextField(verbose_name='متن پیام')
    created_date = models.DateTimeField(verbose_name='تاریخ ایجاد' , auto_now_add=True)
    response = models.TextField(verbose_name='متن تماس پاسخ باما' , null=True , blank=True)
    is_read_by_admin = models.BooleanField(verbose_name='خوانده شده / نشده' , default=False)
    class Meta:
        verbose_name = 'تماس با ما'
        verbose_name_plural = 'لیست تماس با ما'

    def __str__(self):
        return self.full_name
    