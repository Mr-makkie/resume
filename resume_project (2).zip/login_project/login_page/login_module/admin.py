from django.contrib import admin
from . import models
# Register your models here.
admin.site.register(models.InfoModel)
admin.site.register(models.DomailModel)
admin.site.register(models.PartnerModel)
admin.site.register(models.WorksView)
admin.site.register(models.ContactUs)